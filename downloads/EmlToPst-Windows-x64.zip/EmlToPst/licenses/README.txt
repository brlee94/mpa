This application uses the following third-party components:

- MimeKit 4.18.2, MIT license. See MimeKit-LICENSE.txt.
  https://github.com/jstedfast/MimeKit
- BouncyCastle.Cryptography 2.7.0, MIT-style license.
  See BouncyCastle-LICENSE.txt in the distribution.
  https://github.com/bcgit/bc-csharp
- Microsoft .NET 10 and Windows Desktop Runtime; Microsoft packages.
  Runtime licenses and third-party notices are included in the distribution.

The executable distribution contains these runtime dependencies. No separate
runtime installation is required. Microsoft Outlook is not bundled.
